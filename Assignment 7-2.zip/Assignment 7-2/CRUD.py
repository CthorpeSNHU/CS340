import pymongo

class AnimalShelter:

    def __init__(self, database_name, collection_name):
        self.client = MongoClient("mongodb://localhost:32675")
        self.database = self.client[dataase]
        self.collection = delf.database[collections]

    def create(self, data):
            if data is not None:
                insert = self.database.animals.insert_one(data)
                if insertStatus != 0:
                    return False
                return True
            else:
                raise Exception("Data empty, no save required")
                
    def read(self, queryData):
            if queryData:
                inputData = self.database.animals.find({}, {"_id": False})
            else:
                inputData = self.database.animals.find({}, {"_id": False})
            return inputData    
                
    def update(self, inputData, newData):
            if inputData is not None:
                success = self.database.animals.update_many(inputData, {"$set": newData})               
            else:
                return "{}"
            return success
                                                              
    def delete(self, deleteData):
            if deleteData is not None:
                data = self.dataase.animal.delete_many(deleteData)
            else:
                return "{}"
            return data
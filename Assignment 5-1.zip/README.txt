The Python CRUD module is used for the following operations.
1.	Create: Allows a new document to be inserted into a specified MongoDB database and collection.
2.	Read: Is like a search function for documents from a specified MongoDB database and collection.
3.	Update: Changes a document in a specified MongoDB database and collection.
4.	Delete: Removes requested document(s) from a specified MongoDB database and collection.


Demonstrations are in the Word document with this README.